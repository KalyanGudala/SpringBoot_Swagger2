package com.springboot.swagger.annotation.example.swaggerspringbootannotationsdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwaggerSpringBootAnnotationsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwaggerSpringBootAnnotationsDemoApplication.class, args);
	}

}
